
from django.contrib import auth
from django.contrib.auth import authenticate, logout,login
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render,redirect
from django.http import HttpResponseRedirect,HttpResponse
from django.contrib.auth.decorators import login_required

from .forms import RegistrationForm
from django.contrib import messages
# Create your views here.
def index(request):
    return render(request,'basic_app/index.html')

def register(responce):
    if responce.method=="POST":
        form=RegistrationForm(responce.POST)
        if form.is_valid():
            form.save()
        messages.success(responce,'succesfully loged in')
        return redirect("/")
    else:
        form=RegistrationForm()
    return render(responce,'register/register.html',{"form":form})

def user_login(request):
    if request.method=="POST":
        username=request.POST.get('username')
        password=request.POST.get("password")
        user=authenticate(username=username,password=password)

        if user:
            if user.is_active:
                login(request,user)
                return HttpResponseRedirect('/')
            else:
                return HttpResponse("account not active")
        else:
            return HttpResponse("someone tried but failed")
    else:
        return render(request,'register/login.html',{})

@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/')