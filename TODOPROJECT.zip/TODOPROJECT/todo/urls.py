from django.urls import path,include
from . import views
app_name='todo'
urlpatterns = [
   
    path('', views.IndexView.as_view(), name='index'),

    path('list/', views.home, name='home'),
    path('create/', views.create, name='create'),
    path('list/<int:pk>/delete', views.TodoDeleteView.as_view(), name='delete') ,
    path('list/<int:pk>/update/', views.TodoUpdateView.as_view(), name='update'),
]