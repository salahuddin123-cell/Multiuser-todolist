import django
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.http import request

from django.shortcuts import get_object_or_404, redirect, render
from django.views.generic import (View,TemplateView,
                                ListView,DetailView,
                                CreateView,DeleteView,
                                UpdateView)
from .models import Todo
from basic_app.forms import TodoForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required
# Create your views here.
class IndexView(TemplateView):
    template_name= 'todo/index.html'

@login_required
def home(request):
    if request.user.is_authenticated:
        user=request.user
        todos=Todo.objects.filter(user=user)
        return render(request,'todo/todo_list.html',{'todos':todos})
    return render(request,'todo/index.html')
# class TodoList(ListView):
#     model=Todo
#     context_object_name='todos_list'
    
    # def get_object(self):
    #     return get_object_or_404(SchoolDetail,id=self.kwargs.get("id")) 
     
# class TodoCreateView(LoginRequiredMixin,CreateView):
#     fields = ['name','todo']
#     model = Todo
#     success_url=reverse_lazy('index')
#     def form_valid(self, form):
#         form.instance.uer=self.request.user
#         return super(TodoCreateView,self).form_valid(form)
    # success_url=reverse_lazy('TodoList')
@login_required
def create(request):
    forms=TodoForm(request.POST or None)
    user=User.objects.first()
    if forms.is_valid():
            obj=forms.save(commit=False)
            obj.user=request.user
            obj.save()
            forms=TodoForm()
            return redirect("todo:home")
    return render(request,'todo/todo_form.html',context={'form':forms})
    
    

class TodoDeleteView(DeleteView):
    model = Todo
    success_url = reverse_lazy("todo:home")
    # template_name='delete.html'
class TodoUpdateView(UpdateView):
    fields = ("title","todo")
    model = Todo
